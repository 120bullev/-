﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using турагенство;
using System.Data;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.SqlClient;
using System.Windows.Forms.VisualStyles;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var FIO = "Кучеренко";
            var loginUser = "89550550505";
            var passUser = "132";
            var rol = "Клиент";

            string querystring = $"insert into Пользователи (FIO, Phone, Password, Rol) values('{FIO}', '{loginUser}', '{passUser}', '{rol}')";
            SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-DLQ4A54\SQLEXPRESS02;Initial Catalog=турагент;Integrated Security=True;Encrypt=False");

            SqlCommand command = new SqlCommand(querystring, sqlConnection);

            sqlConnection.Open();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("фамилия уебская", "аккаунт создан");
                
            }
            else
            {
                MessageBox.Show("ты долбаеб", "аккаунт не создан");

            }
        }

        [TestMethod]
        public void TestMethod2() 
        {
            var loginUser = "89550550505";
            var passUser = "132";

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = $"SELECT COUNT(*) FROM Пользователи WHERE Phone = @phone AND Password = @password";

            SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-DLQ4A54\SQLEXPRESS02;Initial Catalog=турагент;Integrated Security=True;Encrypt=False");
            SqlCommand command = new SqlCommand(querystring, sqlConnection);
            sqlConnection.Open();

            adapter.SelectCommand = command;

            command.Parameters.AddWithValue("@phone", loginUser);
            command.Parameters.AddWithValue("@password", passUser);

            int count = (int)command.ExecuteScalar();
            if (count > 0)
            {
                MessageBox.Show("Вы успешно зашли!", "Красава наху!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                

            }
            else
            {
                MessageBox.Show("Такого акка нету!", "ЛОХ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        [TestMethod]

        public void TestMethod3() 
        {
            var ID_sup_app ="3";
            var DIR = "Москва";
            var quantity = "3";
            var DATE = "2024-18-11";
            var ID_Client = "1";
            var Phone = "89805553535";

            string querystring = $"insert into Заявки ( ID_оставленой_заявки,  Направление, Количество_людей, Дата_отправления, ID_клиента, Контактные_данные) VALUES ( '{ID_sup_app}', '{DIR}', '{quantity}', '{DATE}', '{ID_Client}', '{Phone}')";

            SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-DLQ4A54\SQLEXPRESS02;Initial Catalog=турагент;Integrated Security=True;Encrypt=False");
            SqlCommand command = new SqlCommand(querystring, sqlConnection);
            sqlConnection.Open();

            if (command.ExecuteNonQuery() == 1)
            {

                MessageBox.Show("Такая хуйня, а не заявка!", "Заявка добавлена!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                applications applications = new applications();
                
            }
            else
            {
                MessageBox.Show("ХУИТА", "Эщкере", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            sqlConnection.Close();
        }

        [TestMethod]

        public void TestMethod4() 
        {
            var DIR = "PIZDA";
            var quantity = "ZAVTRA";
            var DATE = "MNOGO";
            var ID_Client = "2";
            var Phone = "DOM SHLUHI";

            string querystring = $"insert into Оставленые_заявки ( Направление, Дата_отправления, Количество_людей, ID_клиента, Контактны_данные) VALUES ( '{DIR}', '{DATE}', '{quantity}',  '{ID_Client}', '{Phone}')";

            SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-DLQ4A54\SQLEXPRESS02;Initial Catalog=турагент;Integrated Security=True;Encrypt=False");
            SqlCommand command = new SqlCommand(querystring, sqlConnection);
            sqlConnection.Open();


            if (command.ExecuteNonQuery() == 1)
            {

                MessageBox.Show("Такая хуйня, а не заявка!", "Заявка добавлена!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                submitted_applications SUB = new submitted_applications();
            }
            else
            {
                MessageBox.Show("ХУИТА", "Эщкере", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            sqlConnection.Close();
        }

        [TestMethod]

        public void TestMethod5()
        {
            var FIO = "Cgbhbljyjd";
            var loginUser = "89550550505";
            var passUser = "132";
            var rol = "Клиент";

            string querystring = $"insert into Пользователи (FIO, Phone, Password, Rol) values('{FIO}', '{loginUser}', '{passUser}', '{rol}')";
            SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-DLQ4A54\SQLEXPRESS02;Initial Catalog=турагент;Integrated Security=True;Encrypt=False");

            SqlCommand command = new SqlCommand(querystring, sqlConnection);

            sqlConnection.Open();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("фамилия уебская", "аккаунт создан");

            }
            else
            {
                MessageBox.Show("ты долбаеб", "аккаунт не создан");

            }
        }
        [TestMethod]

        public void TestMethod6()
        {
            var ID_sup_app = "3";
            var DIR = "Джубга";
            var quantity = "3";
            var DATE = "2024-18-11";
            var ID_Client = "1";
            var Phone = "89805553535";

            string querystring = $"insert into Заявки ( ID_оставленой_заявки,  Направление, Количество_людей, Дата_отправления, ID_клиента, Контактные_данные) VALUES ( '{ID_sup_app}', '{DIR}', '{quantity}', '{DATE}', '{ID_Client}', '{Phone}')";

            SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-DLQ4A54\SQLEXPRESS02;Initial Catalog=турагент;Integrated Security=True;Encrypt=False");
            SqlCommand command = new SqlCommand(querystring, sqlConnection);
            sqlConnection.Open();

            if (command.ExecuteNonQuery() == 1)
            {

                MessageBox.Show("Такая хуйня, а не заявка!", "Заявка добавлена!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                applications applications = new applications();

            }
            else
            {
                MessageBox.Show("ХУИТА", "Эщкере", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            sqlConnection.Close();
        }
    }
}

﻿namespace турагенство
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_app = new System.Windows.Forms.Button();
            this.button_subApp = new System.Windows.Forms.Button();
            this.button_users = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_app
            // 
            this.button_app.Location = new System.Drawing.Point(164, 107);
            this.button_app.Name = "button_app";
            this.button_app.Size = new System.Drawing.Size(200, 89);
            this.button_app.TabIndex = 0;
            this.button_app.Text = "Заявки";
            this.button_app.UseVisualStyleBackColor = true;
            this.button_app.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_subApp
            // 
            this.button_subApp.Location = new System.Drawing.Point(394, 110);
            this.button_subApp.Name = "button_subApp";
            this.button_subApp.Size = new System.Drawing.Size(264, 86);
            this.button_subApp.TabIndex = 1;
            this.button_subApp.Text = "Оставленные заявки";
            this.button_subApp.UseVisualStyleBackColor = true;
            this.button_subApp.Click += new System.EventHandler(this.button_subApp_Click);
            // 
            // button_users
            // 
            this.button_users.Location = new System.Drawing.Point(256, 202);
            this.button_users.Name = "button_users";
            this.button_users.Size = new System.Drawing.Size(276, 156);
            this.button_users.TabIndex = 2;
            this.button_users.Text = "Пользователи";
            this.button_users.UseVisualStyleBackColor = true;
            this.button_users.Click += new System.EventHandler(this.button_users_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(13, 13);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "Выход";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button_users);
            this.Controls.Add(this.button_subApp);
            this.Controls.Add(this.button_app);
            this.Name = "Menu";
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_app;
        private System.Windows.Forms.Button button_subApp;
        private System.Windows.Forms.Button button_users;
        private System.Windows.Forms.Button button4;
    }
}
﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace турагенство
{
    enum RowState 
    { 
         Existed,
         New,
         Modified,
         ModifiedNew,
         Deleted
    }
    public partial class applications : Form
    {
        Database database = new Database();
        public applications()
        {
            InitializeComponent();
        }

        private void CreateColumns()
        {
            dataGridView1.Columns.Add("ID_заявки", "Заявка");
            dataGridView1.Columns.Add("ID_оставленой_заявки", "Оставленная заявка");
            dataGridView1.Columns.Add("Направление", "Направление");
            dataGridView1.Columns.Add("Количество_людей", "Кол-во человек");
            dataGridView1.Columns.Add("Дата_отправления", "Дата отправления");
            dataGridView1.Columns.Add("ID_клиента", "Клиент");
            dataGridView1.Columns.Add("Контактные_данные", "Номер телефона");
            dataGridView1.Columns.Add("IsNew", String.Empty);
        }

        private void ReadSingleRows(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), record.GetString(4), record.GetString(5), record.GetString(6), RowState.ModifiedNew);
        }

        private void RefreshDataGrid(DataGridView dgw) 
        {
            dgw.Rows.Clear();

            string querystring = $"select * from Заявки";

            SqlCommand command = new SqlCommand(querystring, database.getConnection());

            database.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read()) 
            { 
                ReadSingleRows(dgw, reader);
            }
           
            database.closeConnection();
        }

        private void applications_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridView1);
        }

        private void delteRow() 
        { 
            int index = dataGridView1.CurrentCell.RowIndex;

            dataGridView1.Rows[index].Visible = false;

            if (dataGridView1.Rows[index].Cells[0].Value.ToString() == string.Empty) 
            {
                dataGridView1.Rows[index].Cells[6].Value = RowState.Deleted;
                return;
            }

            dataGridView1.Rows[index].Cells[6].Value = RowState.Deleted;
        }

        private void Update() 
        {
            database.openConnection();

            for(int index = 0;  index < dataGridView1.Rows.Count; index++) 
            { 
                var rowstate = (RowState)dataGridView1.Rows[index].Cells[6].Value;
             
                
                if (rowstate == RowState.Existed)
                    continue;

                if (rowstate == RowState.Deleted) 
                { 
                    var id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
                    var deleteQuery = $"delete from Заявки where ID_заявки = {id}";

                    var command = new SqlCommand(deleteQuery, database.getConnection());
                    command.ExecuteNonQuery();
                }
            }

            database.closeConnection();
        }

        private void button_Add_Click(object sender, EventArgs e)
        {
            add_form add = new add_form();
            this.Hide();
            add.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            this.Hide();
            menu.ShowDialog();
        }

        private void buttonUp_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridView1);
        }

        private void buttonDel_Click(object sender, EventArgs e)
        {
            delteRow();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            Update();
        }
    }
}

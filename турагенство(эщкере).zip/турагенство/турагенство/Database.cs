﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;

namespace турагенство
{
    class Database
    {



        SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-DLQ4A54\SQLEXPRESS02;Initial Catalog=турагент;Integrated Security=True;Encrypt=False");


        public void openConnection()
        {
            if (sqlConnection.State == System.Data.ConnectionState.Closed);
            {

                sqlConnection.Open();

            }
        }

        public void closeConnection()
        {
            if (sqlConnection.State == System.Data.ConnectionState.Open);
            {

                sqlConnection.Close();

            }
        }

        public SqlConnection getConnection() 
        { 
            return sqlConnection;
        }

        
    }
}

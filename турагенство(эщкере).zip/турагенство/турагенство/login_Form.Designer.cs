﻿namespace турагенство
{
    partial class login_Form
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(login_Form));
            this.buttonEnt = new System.Windows.Forms.Button();
            this.buttonReg = new System.Windows.Forms.Button();
            this.textBox_TEL = new System.Windows.Forms.TextBox();
            this.textBox_PASS = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonEnt
            // 
            this.buttonEnt.Location = new System.Drawing.Point(527, 263);
            this.buttonEnt.Name = "buttonEnt";
            this.buttonEnt.Size = new System.Drawing.Size(75, 23);
            this.buttonEnt.TabIndex = 0;
            this.buttonEnt.Text = "Вход";
            this.buttonEnt.UseVisualStyleBackColor = true;
            this.buttonEnt.Click += new System.EventHandler(this.buttonEnt_Click);
            // 
            // buttonReg
            // 
            this.buttonReg.Location = new System.Drawing.Point(12, 164);
            this.buttonReg.Name = "buttonReg";
            this.buttonReg.Size = new System.Drawing.Size(120, 104);
            this.buttonReg.TabIndex = 1;
            this.buttonReg.Text = "Регистрация";
            this.buttonReg.UseVisualStyleBackColor = true;
            this.buttonReg.Click += new System.EventHandler(this.buttonReg_Click);
            // 
            // textBox_TEL
            // 
            this.textBox_TEL.Location = new System.Drawing.Point(513, 144);
            this.textBox_TEL.Name = "textBox_TEL";
            this.textBox_TEL.Size = new System.Drawing.Size(100, 22);
            this.textBox_TEL.TabIndex = 2;
            // 
            // textBox_PASS
            // 
            this.textBox_PASS.Location = new System.Drawing.Point(513, 205);
            this.textBox_PASS.Name = "textBox_PASS";
            this.textBox_PASS.Size = new System.Drawing.Size(100, 22);
            this.textBox_PASS.TabIndex = 3;
            // 
            // login_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(652, 642);
            this.Controls.Add(this.textBox_PASS);
            this.Controls.Add(this.textBox_TEL);
            this.Controls.Add(this.buttonReg);
            this.Controls.Add(this.buttonEnt);
            this.Name = "login_Form";
            this.Text = "ч";
            this.Load += new System.EventHandler(this.login_Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonEnt;
        private System.Windows.Forms.Button buttonReg;
        private System.Windows.Forms.TextBox textBox_TEL;
        private System.Windows.Forms.TextBox textBox_PASS;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Input;

namespace турагенство
{
    public partial class add_form : Form
    {
        Database database = new Database();
        public add_form()
        {
            InitializeComponent();
        }

        private void buttonADD_Click(object sender, EventArgs e)
        {
            

            
            var ID_sup_app = textBoxID_Sub.Text;
            var DIR = textBoxDIR.Text;
            var quantity = textBoxquantity.Text;
            var DATE = textBoxDATE.Text;
            var ID_Client = textBoxID_CLIENT.Text;
            var Phone = textBoxPhone.Text;

            string querystring =  $"insert into Заявки ( ID_оставленой_заявки,  Направление, Количество_людей, Дата_отправления, ID_клиента, Контактные_данные) VALUES ( '{ID_sup_app}', '{DIR}', '{quantity}', '{DATE}', '{ID_Client}', '{Phone}')";

            SqlCommand command = new SqlCommand(querystring, database.getConnection());
            database.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                
                MessageBox.Show("Такая хуйня, а не заявка!", "Заявка добавлена!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                applications applications = new applications();
                this.Hide();
                applications.ShowDialog();
            }
            else 
            {
                MessageBox.Show("ХУИТА", "Эщкере", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            database.closeConnection();
        }
    }
}

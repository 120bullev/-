﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace турагенство
{
    public partial class users : Form
    {
        Database database = new Database();

        public users()
        {
            InitializeComponent();
        }

        private void CreateColumns()
        {
            dataGridView3.Columns.Add("ID_User", "User");
            dataGridView3.Columns.Add("FIO", "ФИО");
            dataGridView3.Columns.Add("Phone", "Телефон");
            dataGridView3.Columns.Add("Password", "Пароль");
            dataGridView3.Columns.Add("Rol", "Роль");
           
        }

        private void ReadSingleRows(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), record.GetString(4), RowState.ModifiedNew);
        }

        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string querystring = $"select * from Пользователи";

            SqlCommand command = new SqlCommand(querystring, database.getConnection());

            database.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRows(dgw, reader);
            }

            database.closeConnection();
        }

        private void users_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridView3);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Data.SqlClient;

namespace турагенство
{
    public partial class add_form2 : Form
    {

        Database database = new Database();
        public add_form2()
        {
            InitializeComponent();
        }

        private void add_form2_Load(object sender, EventArgs e)
        {

        }

        private void buttonADD2_Click(object sender, EventArgs e)
        {
            var DIR = textBoxDIR2.Text;
            var quantity = textBoxquantity2.Text;
            var DATE = textBoxDATE2.Text;
            var ID_Client = textBoxID_CLIENT2.Text;
            var Phone = textBoxPhone2.Text;

            string querystring = $"insert into Оставленые_заявки ( Направление, Дата_отправления, Количество_людей, ID_клиента, Контактны_данные) VALUES ( '{DIR}', '{DATE}', '{quantity}',  '{ID_Client}', '{Phone}')";

            SqlCommand command = new SqlCommand(querystring, database.getConnection());
            database.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {

                MessageBox.Show("Такая хуйня, а не заявка!", "Заявка добавлена!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                submitted_applications SUB = new submitted_applications();
                this.Hide();
                SUB.ShowDialog();
            }
            else
            {
                MessageBox.Show("ХУИТА", "Эщкере", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            database.closeConnection();
        }
    }
}

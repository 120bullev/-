﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace турагенство
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            applications applications = new applications();
            this.Hide();
            applications.ShowDialog();

        }

        private void button_subApp_Click(object sender, EventArgs e)
        {
            submitted_applications sup = new submitted_applications();
            this.Hide();
            sup.ShowDialog();
        }

        private void button_users_Click(object sender, EventArgs e)
        {
            users users = new users();
            this.Hide(); 
            users.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            login_Form login = new login_Form();
            this.Hide();
            login.ShowDialog();

        }
    }
}

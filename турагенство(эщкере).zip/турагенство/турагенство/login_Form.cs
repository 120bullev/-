﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace турагенство
{
    public partial class login_Form : Form
    {

        Database database = new Database();

        public login_Form()
        {
            InitializeComponent();
        }

        private void login_Form_Load(object sender, EventArgs e)
        {

        }

        private void buttonReg_Click(object sender, EventArgs e)
        {
            registr_form frm = new registr_form();
            frm.Show();
            this.Hide();
        }

        private void buttonEnt_Click(object sender, EventArgs e)
        {
            var loginUser = textBox_TEL.Text;
            var passUser = textBox_PASS.Text;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = $"SELECT COUNT(*) FROM Пользователи WHERE Phone = @phone AND Password = @password";

            SqlCommand sqlCommand = new SqlCommand(querystring, database.getConnection());
            database.openConnection();

            adapter.SelectCommand = sqlCommand;

            sqlCommand.Parameters.AddWithValue("@phone", loginUser);
            sqlCommand.Parameters.AddWithValue("@password", passUser);

            int count = (int)sqlCommand.ExecuteScalar();
            if (count > 0)
            {
                MessageBox.Show("Вы успешно зашли!", "Красава наху!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Menu menu = new Menu();
                this.Show();
                menu.ShowDialog();
                
            }
            else 
            {
                MessageBox.Show("Такого акка нету!", "ЛОХ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }
    }
}

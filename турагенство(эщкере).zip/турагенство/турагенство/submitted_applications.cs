﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace турагенство
{
    public partial class submitted_applications : Form
    {

        enum RowState
        {
            Existed,
            New,
            Modified,
            ModifiedNew,
            Deleted
        }

        Database database = new Database();
        public submitted_applications()
        {
            InitializeComponent();
        }

        private void CreateColumns2()
        {
            
            dataGridView2.Columns.Add("ID_оставленой_заявки", "Оставленная заявка");
            dataGridView2.Columns.Add("Направление", "Направление");
            dataGridView2.Columns.Add("Дата_отправления", "Дата отправления");
            dataGridView2.Columns.Add("Количество_людей", "Кол-во человек");
            dataGridView2.Columns.Add("ID_клиента", "Клиент");
            dataGridView2.Columns.Add("Контактные_данные", "Номер телефона");
        }

        private void ReadSingleRows(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), record.GetString(4), record.GetString(5), RowState.ModifiedNew);
        }

        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string querystring = $"select * from Оставленые_заявки";

            SqlCommand command = new SqlCommand(querystring, database.getConnection());

            database.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRows(dgw, reader);
            }

            database.closeConnection();
        }

        private void submitted_applications_Load(object sender, EventArgs e)
        {
            CreateColumns2();
            RefreshDataGrid(dataGridView2);
        }

        private void delteRow()
        {
            int index = dataGridView2.CurrentCell.RowIndex;

            dataGridView2.Rows[index].Visible = false;

            if (dataGridView2.Rows[index].Cells[0].Value.ToString() == string.Empty)
            {
                dataGridView2.Rows[index].Cells[5].Value = RowState.Deleted;
                return;
            }

            dataGridView2.Rows[index].Cells[5].Value = RowState.Deleted;
        }

        private void Update()
        {
            database.openConnection();

            for (int index = 0; index < dataGridView2.Rows.Count; index++)
            {
                var rowstate = (RowState)dataGridView2.Rows[index].Cells[5].Value;


                if (rowstate == RowState.Existed)
                    continue;

                if (rowstate == RowState.Deleted)
                {
                    var id = Convert.ToInt32(dataGridView2.Rows[index].Cells[0].Value);
                    var deleteQuery = $"delete from Заявки where ID_заявки = {id}";

                    var command = new SqlCommand(deleteQuery, database.getConnection());
                    command.ExecuteNonQuery();
                }
            }

            database.closeConnection();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            this.Hide();
            menu.ShowDialog();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button_Add2_Click(object sender, EventArgs e)
        {
            add_form2 add = new add_form2();
            this.Hide();
            add.ShowDialog();
        }

        private void buttonUp2_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridView2);
        }

        private void buttonSave2_Click(object sender, EventArgs e)
        {
            Update();
        }

        private void buttonDel2_Click(object sender, EventArgs e)
        {
            delteRow();
        }
    }
}

﻿namespace турагенство
{
    partial class submitted_applications
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSave2 = new System.Windows.Forms.Button();
            this.buttonUp2 = new System.Windows.Forms.Button();
            this.buttonDel2 = new System.Windows.Forms.Button();
            this.button_Add2 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSave2
            // 
            this.buttonSave2.Location = new System.Drawing.Point(12, 155);
            this.buttonSave2.Name = "buttonSave2";
            this.buttonSave2.Size = new System.Drawing.Size(104, 23);
            this.buttonSave2.TabIndex = 11;
            this.buttonSave2.Text = "Сохранить";
            this.buttonSave2.UseVisualStyleBackColor = true;
            this.buttonSave2.Click += new System.EventHandler(this.buttonSave2_Click);
            // 
            // buttonUp2
            // 
            this.buttonUp2.Location = new System.Drawing.Point(12, 195);
            this.buttonUp2.Name = "buttonUp2";
            this.buttonUp2.Size = new System.Drawing.Size(104, 23);
            this.buttonUp2.TabIndex = 10;
            this.buttonUp2.Text = "Обновить";
            this.buttonUp2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonUp2.UseVisualStyleBackColor = true;
            this.buttonUp2.Click += new System.EventHandler(this.buttonUp2_Click);
            // 
            // buttonDel2
            // 
            this.buttonDel2.Location = new System.Drawing.Point(12, 110);
            this.buttonDel2.Name = "buttonDel2";
            this.buttonDel2.Size = new System.Drawing.Size(104, 23);
            this.buttonDel2.TabIndex = 9;
            this.buttonDel2.Text = "Удалить";
            this.buttonDel2.UseVisualStyleBackColor = true;
            this.buttonDel2.Click += new System.EventHandler(this.buttonDel2_Click);
            // 
            // button_Add2
            // 
            this.button_Add2.Location = new System.Drawing.Point(12, 66);
            this.button_Add2.Name = "button_Add2";
            this.button_Add2.Size = new System.Drawing.Size(104, 23);
            this.button_Add2.TabIndex = 8;
            this.button_Add2.Text = "Добавить";
            this.button_Add2.UseVisualStyleBackColor = true;
            this.button_Add2.Click += new System.EventHandler(this.button_Add2_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 21);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Назад";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(137, 21);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(1183, 498);
            this.dataGridView2.TabIndex = 6;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // submitted_applications
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1418, 551);
            this.Controls.Add(this.buttonSave2);
            this.Controls.Add(this.buttonUp2);
            this.Controls.Add(this.buttonDel2);
            this.Controls.Add(this.button_Add2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView2);
            this.Name = "submitted_applications";
            this.Text = "submitted_applications";
            this.Load += new System.EventHandler(this.submitted_applications_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonSave2;
        private System.Windows.Forms.Button buttonUp2;
        private System.Windows.Forms.Button buttonDel2;
        private System.Windows.Forms.Button button_Add2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}
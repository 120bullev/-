﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace турагенство
{
    public partial class registr_form : Form
    {
        Database database = new Database();
        public registr_form()
        {
            InitializeComponent();
            CustomizeForm();
        }

        private void CustomizeForm()
        {
            comboBox1.Items.Add("Клиент");
            comboBox1.Items.Add("Менеджер");
            comboBox1.Items.Add("Администратор");
            comboBox1.SelectedIndex = 0;
        }



        private void textBox_fio_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            var FIO = textBox_fio.Text;
            var loginUser = textBox_phone.Text;
            var passUser = textBox_pass.Text;
            var rol = comboBox1.SelectedItem.ToString();

            string querystring = $"insert into Пользователи (FIO, Phone, Password, Rol) values('{FIO}', '{loginUser}', '{passUser}', '{rol}')";

            SqlCommand command = new SqlCommand(querystring, database.getConnection());

            database.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("фамилия уебская", "аккаунт создан");
                login_Form loginForm = new login_Form();
                this.Hide();
                loginForm.ShowDialog();
            }
            else 
            {
                MessageBox.Show("ты долбаеб", "аккаунт не создан");

            }

          


        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
